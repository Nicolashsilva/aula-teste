import aluno as a
import turma as t

alunos = []
try:
    alunos.append(a.Aluno('Fabio', 'Teixeira', 8))
    alunos.append(a.Aluno('Fabiano', 'Teixeira', 10))
    alunos.append(a.Aluno('Melissa', 'Teixeira', -2))
except ValueError as e:
    print(e)

turmaObject = t.Turma()
try:
    turmaObject.cadastrarAlunos(alunos)
except ValueError as e:
    print(e)

turmaObject.mostrarAlunos()
print('*' * 30)
if turmaObject.menorNota:
    print('Aluno com menor nota:', turmaObject.menorNota.mostrarAluno())
if turmaObject.maiorNota:
    print('Aluno com maior nota:', turmaObject.maiorNota.mostrarAluno())
